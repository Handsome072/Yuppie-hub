import styles from "./politiques.module.css";
export default function Settings() {
  return (
    <>
      <div className={styles.container}>Politiques</div>
    </>
  );
}
