import styles from "./about.module.css";
export default function Settings() {
  return (
    <>
      <div className={styles.container}>A propos</div>
    </>
  );
}
