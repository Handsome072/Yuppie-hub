import styles from "./infos.module.css";
export default function Settings() {
  return (
    <>
      <div className={styles.container}>Infos</div>
    </>
  );
}
