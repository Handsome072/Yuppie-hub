import styles from "./contact.module.css";
export default function Settings() {
  return (
    <>
      <div className={styles.container}>Contact</div>
    </>
  );
}
