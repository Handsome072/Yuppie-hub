import styles from "./avis.module.css";
export default function Settings() {
  return (
    <>
      <div className={styles.container}>Avis</div>
    </>
  );
}
