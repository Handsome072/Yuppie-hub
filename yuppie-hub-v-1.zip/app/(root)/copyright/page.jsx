import styles from "./copyright.module.css";
export default function Settings() {
  return (
    <>
      <div className={styles.container}>Copyright</div>
    </>
  );
}
