import styles from "./settings.module.css";
export default function Settings() {
  return (
    <>
      <div className={styles.container}>Settings</div>
    </>
  );
}
