import Spinner from "@/components/Spinner";
export default function Loading() {
  return <Spinner />;
}
