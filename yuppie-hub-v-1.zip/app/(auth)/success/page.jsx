import Success from "@/components/auth/Success";
import AuthPage from "../Auth";
export default function SuccessRegister() {
  return (
    <>
      <AuthPage>
        <Success />
      </AuthPage>
    </>
  );
}
