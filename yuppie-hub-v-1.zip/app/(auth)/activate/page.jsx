import ActivateUserCompte from "@/components/auth/Activate";
import AuthPage from "../Auth";
export default function ActivateUserComptePage() {
  return (
    <AuthPage>
      <ActivateUserCompte />
    </AuthPage>
  );
}
