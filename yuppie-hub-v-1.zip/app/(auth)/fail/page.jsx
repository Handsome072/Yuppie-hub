import Fail from "@/components/auth/Fail";
import AuthPage from "../Auth";
export default function RegisterFail() {
  return (
    <AuthPage>
      <Fail />
    </AuthPage>
  );
}
