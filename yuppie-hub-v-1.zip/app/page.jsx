export default function LandingPage() {
  return null
}
